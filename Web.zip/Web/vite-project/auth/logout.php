<?php
require_once "../includes/auth_check.php";

session_unset();
session_destroy();

setcookie(session_name(), '', time() - 3600, "/");

header("Location: login.php");
exit;
